# PROJECT NAME IS `ALBERTO WATCH SHOP`
## PROGRAMMED BY `GROUP 3` CLASS `CP2396G06` SCHOOL `APTECH CUSC CANTHO UNIVERSITY` 

## PACKAGE REQUIREMENTS 
`bootstrap`
`prop-types`
`react`
`react-dom`
`react-paginate`
`react-router-dom`
`react-scripts`
`react-toastify`
`web-vitals`
`classnames`

## `npm start` TO RUN THIS PROJECT

## V0.0.41
- Complete the sorting operation according to technology.
- Optimize user experience on UI.
- Fix bug...

## V0.0.4
- Completed compatibility for devices with small screens such as phones for home, product, login, and sales pages.
- Optimize user experience on UI.
- Fix bug.

## V0.0.38
- Authenticate and authorize when users log in.
- Add registration link in footer.
- Fix bug.

## V0.0.37 
- Add login and sign up page.
- create event login, sign up, and logout.
- Fix bug.

## V0.0.36
- Add product database.
- Almost completed product page.
- Fix bug.

## ...

