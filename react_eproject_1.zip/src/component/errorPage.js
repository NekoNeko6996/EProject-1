function ErrorPage() {
  return (
    <div style={{display: "flex", flexDirection: "column"}}>
      <h1 style={{ textAlign: "center" }}>Hmm... Something is not true</h1>
      <h1 style={{ textAlign: "center" }}>ERROR 404 PAGE NOT FOUND</h1>
    </div>
  );
}
export default ErrorPage;