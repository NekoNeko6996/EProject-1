import React from "react";


// 
function ServiceComponent() {
  return (
    <>
      <h1>Hmm... something's not right</h1>
      <h2>Looks like it's not done yet</h2>
    </>
  );
}

export default React.memo(ServiceComponent);